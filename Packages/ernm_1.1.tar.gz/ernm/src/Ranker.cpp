/*
 * Ranker.cpp
 *
 *  Created on: Dec 19, 2017
 *      Author: ianfellows
 */
#include "Ranker.h"
