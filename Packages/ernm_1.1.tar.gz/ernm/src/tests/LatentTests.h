/*
 * TestLatent.h
 *
 *  Created on: Jul 1, 2015
 *      Author: goodfellow
 */

#ifndef TESTLATENT_H_
#define TESTLATENT_H_


namespace ernm{
namespace tests{

/*!
 * Tests model statistics.
 */
void testLatent();

}
}



#endif /* TESTLATENT_H_ */
