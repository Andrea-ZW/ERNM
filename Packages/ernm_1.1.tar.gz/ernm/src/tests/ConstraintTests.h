/*
 * ContraintTests.h
 *
 *  Created on: Jan 9, 2014
 *      Author: ianfellows
 */

#ifndef CONTRAINTTESTS_H_
#define CONTRAINTTESTS_H_

namespace ernm {

namespace tests{

void testConstraints();

}
} /* namespace ernm */
#endif /* CONTRAINTTESTS_H_ */
