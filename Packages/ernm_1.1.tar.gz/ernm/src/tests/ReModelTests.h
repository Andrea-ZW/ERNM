/*
 * ReModelTests.h
 *
 *  Created on: Jan 15, 2016
 *      Author: ianfellows
 */

#ifndef REMODELTESTS_H_
#define REMODELTESTS_H_


namespace ernm{
namespace tests{

/*!
 * Tests model statistics.
 */
void testReModel();

}
}


#endif /* REMODELTESTS_H_ */
