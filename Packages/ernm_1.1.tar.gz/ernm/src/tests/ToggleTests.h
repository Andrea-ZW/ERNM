/*
 * ToggleTests.h
 *
 *  Created on: May 6, 2014
 *      Author: ianfellows
 */

#ifndef TOGGLETESTS_H_
#define TOGGLETESTS_H_

namespace ernm{

namespace tests{


/*!
 * Tests BinaryNet (very thin right now).
 */
void testToggles();


}
}


#endif /* TOGGLETESTS_H_ */
