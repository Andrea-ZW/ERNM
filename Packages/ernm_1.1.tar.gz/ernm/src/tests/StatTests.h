/*
 * StatTests.h
 *
 *  Created on: Oct 23, 2012
 *      Author: ianfellows
 */

#ifndef STATTESTS_H_
#define STATTESTS_H_

namespace ernm{
namespace tests{

/*!
 * Tests model statistics.
 */
void testStats();

}
}


#endif /* STATTESTS_H_ */
