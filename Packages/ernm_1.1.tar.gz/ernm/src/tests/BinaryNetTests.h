/*
 * BinaryNetTests.h
 *
 *  Created on: Oct 22, 2012
 *      Author: ianfellows
 */

#ifndef BINARYNETTESTS_H_
#define BINARYNETTESTS_H_

namespace ernm{

namespace tests{


/*!
 * Tests BinaryNet (very thin right now).
 */
void testBinaryNet();


}
}


#endif /* BINARYNETTESTS_H_ */
