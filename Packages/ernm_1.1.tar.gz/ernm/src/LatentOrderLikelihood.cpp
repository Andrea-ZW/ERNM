/*
 * LatentOrderLikelihood.cpp
 *
 *  Created on: Jun 22, 2015
 *      Author: goodfellow
 */

#include "LatentOrderLikelihood.h"


