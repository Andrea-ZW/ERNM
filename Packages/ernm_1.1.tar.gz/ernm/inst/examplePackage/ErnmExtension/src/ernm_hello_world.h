#ifndef _ErnmExtension_ERNM_HELLO_WORLD_H
#define _ErnmExtension_ERNM_HELLO_WORLD_H

#include <Rcpp.h>


Rcpp::List ernm_hello_world() ;

#endif
