

library(testthat)
library(ernm)

test_package("ernm")
