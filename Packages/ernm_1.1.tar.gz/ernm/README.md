# ernm
Estimation of fully/partially observed Exponential-Family Random     Network Models (ERNM). ERNMs are a generalization of ERGM (see the ergm     package) and Gibbs Fields, encompassing both as special cases
